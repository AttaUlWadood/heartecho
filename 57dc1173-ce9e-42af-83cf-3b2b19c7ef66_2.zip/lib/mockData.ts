export const mockStories = [
  {
    id: '1',
    title: 'A Stranger\'s Umbrella Changed My Day',
    content: `It was raining heavily that Tuesday morning when I realized I'd forgotten my umbrella. Standing at the bus stop, completely soaked, I felt like the universe was conspiring against me. That's when an elderly gentleman approached me with a warm smile and handed me his spare umbrella.

"Take this," he said. "I have another one at home." Before I could protest or even thank him properly, he walked away into the rain, leaving me standing there with tears mixing with the raindrops on my face.

That simple act of kindness didn't just keep me dry – it restored my faith in humanity. I've since started carrying spare umbrellas to pass on this beautiful gesture to others. Sometimes the smallest acts create the biggest ripples of change.

The gentleman's name was Robert, and though I never saw him again, his kindness lives on through every umbrella I've shared since that day.`,
    preview: 'It was raining heavily that Tuesday morning when I realized I\'d forgotten my umbrella. Standing at the bus stop, completely soaked, I felt like the universe was conspiring against me...',
    author: 'Sarah M.',
    category: 'Kindness',
    createdAt: '2024-01-15',
    reactions: { heart: 234, cry: 45, praise: 89 }
  },
  {
    id: '2',
    title: 'Finding Light After My Darkest Hour',
    content: `Losing my job, my relationship, and my apartment all in the same month felt like the end of the world. I found myself questioning everything – my worth, my purpose, my future. The darkness seemed endless, and I couldn't see any way forward.

But sometimes, rock bottom becomes the solid foundation on which you rebuild your life. It started with small things – a morning walk, a call to an old friend, volunteering at a local shelter. Each small step forward was a victory against the darkness.

Today, two years later, I'm in a career I love, surrounded by people who truly care about me, and living in a place that feels like home. More importantly, I've learned that strength isn't about never falling – it's about getting back up every time you do.

The darkness taught me to appreciate the light, and now I try to be that light for others who are struggling. We're all fighting battles others can't see, but we're not fighting them alone.`,
    preview: 'Losing my job, my relationship, and my apartment all in the same month felt like the end of the world. I found myself questioning everything – my worth, my purpose, my future...',
    author: 'Michael R.',
    category: 'Hope',
    createdAt: '2024-01-12',
    reactions: { heart: 567, cry: 123, praise: 234 }
  },
  {
    id: '3',
    title: 'The Healing Power of Forgiveness',
    content: `For fifteen years, I carried the weight of anger toward my father. His absence during my childhood created wounds that seemed impossible to heal. I built walls around my heart, convincing myself that forgiveness was weakness.

The turning point came when I received a letter from him – shaky handwriting on faded paper, explaining his struggles with addiction and expressing remorse for the pain he'd caused. For the first time, I saw him not as the villain of my story, but as a broken human being trying to make amends.

Forgiveness wasn't instant or easy. It was a daily choice, a gradual process of releasing the poison I'd been drinking, hoping he would suffer. But as I let go of the anger, I discovered something beautiful – space in my heart for love, joy, and peace.

We met for coffee last month. He's been sober for three years now, and while we can't change the past, we're building something new. Forgiveness didn't erase the hurt, but it gave me the power to write a different ending to our story.

Healing isn't about forgetting or excusing harmful behavior. It's about freeing yourself from the prison of resentment and choosing love over bitterness, even when it's hard.`,
    preview: 'For fifteen years, I carried the weight of anger toward my father. His absence during my childhood created wounds that seemed impossible to heal...',
    author: 'Jennifer L.',
    category: 'Healing',
    createdAt: '2024-01-10',
    reactions: { heart: 389, cry: 178, praise: 167 }
  },
  {
    id: '4',
    title: 'A Prayer Answered in the Most Unexpected Way',
    content: `I had been praying for months for a sign, for direction, for anything that would help me make sense of the chaos in my life. My mother was battling cancer, my marriage was struggling, and I felt like I was drowning in responsibilities and fear.

One evening, exhausted and defeated, I sat in my car in the hospital parking lot and broke down completely. Through my tears, I whispered a desperate prayer: "Please, just show me I'm not alone in this."

That's when I noticed a woman sitting on a nearby bench, also crying. Something moved me to approach her. We were both strangers, both hurting, both feeling lost. We talked for hours that night, sharing our fears, our hopes, and our faith.

Her name was Grace – how perfect is that? She became my prayer partner, and together we supported each other through our darkest moments. Her mother had beaten cancer five years earlier, and she shared practical advice alongside spiritual encouragement.

Today, both our mothers are healthy, our families are stronger, and our friendship is a testament to how God works through human connections. Sometimes the answer to our prayers isn't a miracle from above – it's the person sitting right next to us, equally in need of grace.`,
    preview: 'I had been praying for months for a sign, for direction, for anything that would help me make sense of the chaos in my life. My mother was battling cancer, my marriage was struggling...',
    author: 'David K.',
    category: 'Faith',
    createdAt: '2024-01-08',
    reactions: { heart: 445, cry: 89, praise: 312 }
  },
  {
    id: '5',
    title: 'The Day I Lost My Best Friend',
    content: `Emma and I had been inseparable since kindergarten. We shared everything – secrets, dreams, inside jokes that no one else understood. She was the sister I never had, the person who knew me better than I knew myself.

The phone call came at 2:47 AM on a Saturday. Car accident. Critical condition. Those words still echo in my mind. I rushed to the hospital, praying with every fiber of my being that she would be okay. But sometimes, prayers aren't answered the way we hope.

She held on for three days. Three days of machines beeping, of holding her hand, of whispering all the things I'd never said but should have. Her last words to me were, "Take care of yourself, and don't forget to laugh." Even in her final moments, she was taking care of me.

The grief was overwhelming. Food lost its taste, colors seemed muted, and laughter felt like a betrayal. But slowly, I began to understand what she meant. Living fully wasn't disrespecting her memory – it was honoring it.

I carry her with me in every sunset I pause to admire, every random act of kindness I perform, every moment I choose joy over sorrow. Death ends a life, but it doesn't end a relationship. Love transcends physical presence.

Emma taught me that grief is love with nowhere to go. So I pour that love into living – for both of us.`,
    preview: 'Emma and I had been inseparable since kindergarten. We shared everything – secrets, dreams, inside jokes that no one else understood. She was the sister I never had...',
    author: 'Anonymous',
    category: 'Loss',
    createdAt: '2024-01-05',
    reactions: { heart: 678, cry: 234, praise: 156 }
  },
  {
    id: '6',
    title: 'Teaching My Daughter to Be Brave',
    content: `My eight-year-old daughter came home from school with tears in her eyes. "The other kids said I'm weird because I like science," she whispered. My heart broke watching her doubt herself because of thoughtless comments.

That night, I told her about Marie Curie, who was told women couldn't be scientists. About Katherine Johnson, who calculated rocket trajectories when computers couldn't. About every woman who was called "weird" for being brilliant.

"Weird is wonderful," I told her. "It means you're brave enough to be different, smart enough to ask questions, and strong enough to stand out. Never dim your light because others can't handle your brightness."

The next day, she went to school wearing her favorite space-themed shirt and carrying her microscope for show-and-tell. When she came home, she was beaming. "Three kids asked to look through my microscope, and one girl said she wants to be an astronaut too!"

Watching her confidence bloom reminded me that our job as parents isn't to shield our children from the world, but to give them the tools to navigate it with courage and authenticity.

She's now the leader of her school's science club, and every day she teaches me something new about being brave. Sometimes the student becomes the teacher, and the child shows the parent how to see the world with wonder again.`,
    preview: 'My eight-year-old daughter came home from school with tears in her eyes. "The other kids said I\'m weird because I like science," she whispered...',
    author: 'Patricia W.',
    category: 'Hope',
    createdAt: '2024-01-03',
    reactions: { heart: 523, cry: 67, praise: 289 }
  }
];

export const categories = [
  { name: 'All', value: 'all' },
  { name: 'Hope', value: 'hope' },
  { name: 'Kindness', value: 'kindness' },
  { name: 'Healing', value: 'healing' },
  { name: 'Faith', value: 'faith' },
  { name: 'Loss', value: 'loss' }
];