'use client';

import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-gray-50 border-t border-gray-200 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <Link href="/" className="flex items-center mb-4">
              <span className="text-2xl font-bold text-rose-600" style={{ fontFamily: 'Pacifico, serif' }}>
                HeartStories
              </span>
            </Link>
            <p className="text-gray-600 mb-4">
              A place where hearts connect through shared stories of hope, love, and human experiences.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-rose-600 transition-colors">
                <i className="ri-facebook-fill text-xl"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-rose-600 transition-colors">
                <i className="ri-twitter-fill text-xl"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-rose-600 transition-colors">
                <i className="ri-instagram-fill text-xl"></i>
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-gray-900 tracking-wider uppercase mb-4">
              Quick Links
            </h3>
            <ul className="space-y-2">
              <li>
                <Link href="/browse" className="text-gray-600 hover:text-rose-600 transition-colors">
                  Browse Stories
                </Link>
              </li>
              <li>
                <Link href="/submit" className="text-gray-600 hover:text-rose-600 transition-colors">
                  Submit Your Story
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-gray-600 hover:text-rose-600 transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-600 hover:text-rose-600 transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-gray-900 tracking-wider uppercase mb-4">
              Categories
            </h3>
            <ul className="space-y-2">
              <li>
                <Link href="/browse?category=hope" className="text-gray-600 hover:text-rose-600 transition-colors">
                  Hope
                </Link>
              </li>
              <li>
                <Link href="/browse?category=kindness" className="text-gray-600 hover:text-rose-600 transition-colors">
                  Kindness
                </Link>
              </li>
              <li>
                <Link href="/browse?category=healing" className="text-gray-600 hover:text-rose-600 transition-colors">
                  Healing
                </Link>
              </li>
              <li>
                <Link href="/browse?category=faith" className="text-gray-600 hover:text-rose-600 transition-colors">
                  Faith
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-gray-200">
          <p className="text-center text-gray-600 text-sm">
            © 2024 HeartStories. All rights reserved. Made with ❤️ for sharing human experiences.
          </p>
        </div>
      </div>
    </footer>
  );
}