'use client';

import Link from 'next/link';
import { useState } from 'react';

interface Story {
  id: string;
  title: string;
  content: string;
  preview: string;
  author: string;
  category: string;
  createdAt: string;
  reactions: {
    heart: number;
    cry: number;
    praise: number;
  };
}

interface StoryCardProps {
  story: Story;
}

export default function StoryCard({ story }: StoryCardProps) {
  const [reactions, setReactions] = useState(story.reactions);
  const [userReaction, setUserReaction] = useState<string | null>(null);

  const handleReaction = (type: 'heart' | 'cry' | 'praise') => {
    if (userReaction === type) {
      setReactions(prev => ({
        ...prev,
        [type]: prev[type] - 1
      }));
      setUserReaction(null);
    } else {
      setReactions(prev => ({
        ...prev,
        [userReaction || '']: userReaction ? prev[userReaction as keyof typeof prev] - 1 : prev[userReaction as keyof typeof prev],
        [type]: prev[type] + 1
      }));
      setUserReaction(type);
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category.toLowerCase()) {
      case 'hope': return 'bg-blue-100 text-blue-800';
      case 'kindness': return 'bg-green-100 text-green-800';
      case 'healing': return 'bg-purple-100 text-purple-800';
      case 'faith': return 'bg-yellow-100 text-yellow-800';
      case 'loss': return 'bg-gray-100 text-gray-800';
      default: return 'bg-rose-100 text-rose-800';
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-4">
        <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${getCategoryColor(story.category)}`}>
          {story.category}
        </span>
        <span className="text-gray-500 text-sm">
          {new Date(story.createdAt).toLocaleDateString()}
        </span>
      </div>

      <Link href={`/story/${story.id}`}>
        <h3 className="text-xl font-semibold text-gray-900 mb-3 hover:text-rose-600 transition-colors cursor-pointer">
          {story.title}
        </h3>
      </Link>

      <p className="text-gray-700 mb-4 leading-relaxed">
        {story.preview}
      </p>

      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-rose-100 rounded-full flex items-center justify-center">
            <i className="ri-user-line text-rose-600"></i>
          </div>
          <span className="text-gray-600 text-sm">
            {story.author || 'Anonymous'}
          </span>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={() => handleReaction('heart')}
            className={`flex items-center space-x-1 px-3 py-1 rounded-full text-sm transition-colors ${
              userReaction === 'heart' ? 'bg-red-100 text-red-600' : 'bg-gray-100 text-gray-600 hover:bg-red-100 hover:text-red-600'
            }`}
          >
            <span>❤️</span>
            <span>{reactions.heart}</span>
          </button>

          <button
            onClick={() => handleReaction('cry')}
            className={`flex items-center space-x-1 px-3 py-1 rounded-full text-sm transition-colors ${
              userReaction === 'cry' ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-600 hover:bg-blue-100 hover:text-blue-600'
            }`}
          >
            <span>😢</span>
            <span>{reactions.cry}</span>
          </button>

          <button
            onClick={() => handleReaction('praise')}
            className={`flex items-center space-x-1 px-3 py-1 rounded-full text-sm transition-colors ${
              userReaction === 'praise' ? 'bg-yellow-100 text-yellow-600' : 'bg-gray-100 text-gray-600 hover:bg-yellow-100 hover:text-yellow-600'
            }`}
          >
            <span>🙌</span>
            <span>{reactions.praise}</span>
          </button>
        </div>
      </div>
    </div>
  );
}