
'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center">
            <span className="text-2xl font-bold text-rose-600" style={{ fontFamily: 'Pacifico, serif' }}>
              HeartEcho
            </span>
          </Link>

          <nav className="hidden md:flex space-x-8">
            <Link href="/" className="text-gray-600 hover:text-rose-600 transition-colors">
              Home
            </Link>
            <Link href="/browse" className="text-gray-600 hover:text-rose-600 transition-colors">
              Browse
            </Link>
            <Link href="/submit" className="text-gray-600 hover:text-rose-600 transition-colors">
              Submit Story
            </Link>
            <Link href="/about" className="text-gray-600 hover:text-rose-600 transition-colors">
              About
            </Link>
            <Link href="/contact" className="text-gray-600 hover:text-rose-600 transition-colors">
              Contact
            </Link>
          </nav>

          <button
            className="md:hidden w-6 h-6 flex items-center justify-center"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <i className="ri-menu-line text-xl"></i>
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-100">
            <div className="flex flex-col space-y-3">
              <Link href="/" className="text-gray-600 hover:text-rose-600 transition-colors">
                Home
              </Link>
              <Link href="/browse" className="text-gray-600 hover:text-rose-600 transition-colors">
                Browse
              </Link>
              <Link href="/submit" className="text-gray-600 hover:text-rose-600 transition-colors">
                Submit Story
              </Link>
              <Link href="/about" className="text-gray-600 hover:text-rose-600 transition-colors">
                About
              </Link>
              <Link href="/contact" className="text-gray-600 hover:text-rose-600 transition-colors">
                Contact
              </Link>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
