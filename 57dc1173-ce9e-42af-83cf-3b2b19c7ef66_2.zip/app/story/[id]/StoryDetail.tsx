'use client';

import { useState, useEffect } from 'react';
import { mockStories } from '@/lib/mockData';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';
import { notFound } from 'next/navigation';

interface StoryDetailProps {
  storyId: string;
}

export default function StoryDetail({ storyId }: StoryDetailProps) {
  const [story, setStory] = useState<any>(null);
  const [reactions, setReactions] = useState({ heart: 0, cry: 0, praise: 0 });
  const [userReaction, setUserReaction] = useState<string | null>(null);

  useEffect(() => {
    const foundStory = mockStories.find(s => s.id === storyId);
    if (foundStory) {
      setStory(foundStory);
      setReactions(foundStory.reactions);
    }
  }, [storyId]);

  if (!story) {
    notFound();
  }

  const handleReaction = (type: 'heart' | 'cry' | 'praise') => {
    if (userReaction === type) {
      setReactions(prev => ({
        ...prev,
        [type]: prev[type] - 1
      }));
      setUserReaction(null);
    } else {
      setReactions(prev => ({
        ...prev,
        [userReaction || '']: userReaction ? prev[userReaction as keyof typeof prev] - 1 : prev[userReaction as keyof typeof prev],
        [type]: prev[type] + 1
      }));
      setUserReaction(type);
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category.toLowerCase()) {
      case 'hope': return 'bg-blue-100 text-blue-800';
      case 'kindness': return 'bg-green-100 text-green-800';
      case 'healing': return 'bg-purple-100 text-purple-800';
      case 'faith': return 'bg-yellow-100 text-yellow-800';
      case 'loss': return 'bg-gray-100 text-gray-800';
      default: return 'bg-rose-100 text-rose-800';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 to-orange-50">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8">
          <Link 
            href="/"
            className="inline-flex items-center text-rose-600 hover:text-rose-700 transition-colors"
          >
            <i className="ri-arrow-left-line mr-2"></i>
            Back to Stories
          </Link>
        </div>

        <article className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-8">
            <div className="flex items-center justify-between mb-6">
              <span className={`inline-flex items-center px-4 py-2 rounded-full text-sm font-medium ${getCategoryColor(story.category)}`}>
                {story.category}
              </span>
              <span className="text-gray-500">
                {new Date(story.createdAt).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </span>
            </div>

            <h1 className="text-4xl font-bold text-gray-900 mb-6 leading-tight">
              {story.title}
            </h1>

            <div className="flex items-center mb-8">
              <div className="w-12 h-12 bg-rose-100 rounded-full flex items-center justify-center mr-4">
                <i className="ri-user-line text-rose-600 text-xl"></i>
              </div>
              <div>
                <p className="font-medium text-gray-900">{story.author || 'Anonymous'}</p>
                <p className="text-sm text-gray-500">Story contributor</p>
              </div>
            </div>

            <div className="prose prose-lg max-w-none mb-8">
              {story.content.split('\n\n').map((paragraph: string, index: number) => (
                <p key={index} className="text-gray-700 leading-relaxed mb-6">
                  {paragraph}
                </p>
              ))}
            </div>

            <div className="border-t border-gray-200 pt-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                How did this story make you feel?
              </h3>
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => handleReaction('heart')}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    userReaction === 'heart' 
                      ? 'bg-red-100 text-red-600' 
                      : 'bg-gray-100 text-gray-600 hover:bg-red-100 hover:text-red-600'
                  }`}
                >
                  <span className="text-lg">❤️</span>
                  <span>Loved ({reactions.heart})</span>
                </button>

                <button
                  onClick={() => handleReaction('cry')}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    userReaction === 'cry' 
                      ? 'bg-blue-100 text-blue-600' 
                      : 'bg-gray-100 text-gray-600 hover:bg-blue-100 hover:text-blue-600'
                  }`}
                >
                  <span className="text-lg">😢</span>
                  <span>Moved ({reactions.cry})</span>
                </button>

                <button
                  onClick={() => handleReaction('praise')}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    userReaction === 'praise' 
                      ? 'bg-yellow-100 text-yellow-600' 
                      : 'bg-gray-100 text-gray-600 hover:bg-yellow-100 hover:text-yellow-600'
                  }`}
                >
                  <span className="text-lg">🙌</span>
                  <span>Inspired ({reactions.praise})</span>
                </button>
              </div>
            </div>
          </div>
        </article>

        <div className="mt-12 text-center">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">
            Share Your Own Story
          </h3>
          <p className="text-gray-600 mb-6">
            Every story matters. Your experience could be exactly what someone needs to hear today.
          </p>
          <Link
            href="/submit"
            className="bg-rose-600 text-white px-8 py-3 rounded-xl font-semibold hover:bg-rose-700 transition-colors inline-flex items-center whitespace-nowrap"
          >
            <i className="ri-heart-line mr-2"></i>
            Share Your Story
          </Link>
        </div>
      </div>

      <Footer />
    </div>
  );
}