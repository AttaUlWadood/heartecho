'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import StoryCard from '@/components/StoryCard';
import SearchAndFilter from '@/components/SearchAndFilter';
import { mockStories } from '@/lib/mockData';
import { useState, useMemo } from 'react';
import Link from 'next/link';

export default function Home() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState('newest');

  const filteredStories = useMemo(() => {
    let filtered = mockStories;

    // Filter by search query
    if (searchQuery) {
      filtered = filtered.filter(story => 
        story.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        story.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
        story.author.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Filter by category
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(story => 
        story.category.toLowerCase() === selectedCategory.toLowerCase()
      );
    }

    // Sort stories
    filtered.sort((a, b) => {
      if (sortBy === 'newest') {
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      } else {
        const aTotal = a.reactions.heart + a.reactions.cry + a.reactions.praise;
        const bTotal = b.reactions.heart + b.reactions.cry + b.reactions.praise;
        return bTotal - aTotal;
      }
    });

    return filtered;
  }, [searchQuery, selectedCategory, sortBy]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 to-orange-50">
      <Header />
      
      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=Warm%20golden%20sunset%20with%20soft%20clouds%20and%20gentle%20light%20rays%20creating%20a%20peaceful%20and%20hopeful%20atmosphere%20perfect%20for%20emotional%20storytelling%20website%20background%20with%20subtle%20warmth%20and%20comfort%20feeling%20soft%20pastel%20colors%20dreamy%20sky%20serene%20landscape&width=1200&height=600&seq=hero-bg&orientation=landscape')`
          }}
        >
          <div className="absolute inset-0 bg-white/70"></div>
        </div>
        
        <div className="relative max-w-4xl mx-auto text-center">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
            Share Your Heart,
            <span className="text-rose-600"> Touch Others</span>
          </h1>
          <p className="text-xl text-gray-700 mb-8 max-w-2xl mx-auto leading-relaxed">
            A safe space where real stories create real connections. Every experience shared here has the power to heal, inspire, and remind us we're not alone.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/submit"
              className="bg-rose-600 text-white px-8 py-3 rounded-xl font-semibold hover:bg-rose-700 transition-colors inline-flex items-center justify-center whitespace-nowrap"
            >
              <i className="ri-heart-line mr-2"></i>
              Share Your Story
            </Link>
            <Link
              href="/browse"
              className="bg-white text-rose-600 px-8 py-3 rounded-xl font-semibold border-2 border-rose-600 hover:bg-rose-50 transition-colors inline-flex items-center justify-center whitespace-nowrap"
            >
              <i className="ri-book-open-line mr-2"></i>
              Read Stories
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Stories Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Recent Stories
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Discover touching stories from our community. Each one is a window into the human experience, shared with courage and vulnerability.
            </p>
          </div>

          <SearchAndFilter
            onSearch={setSearchQuery}
            onCategoryChange={setSelectedCategory}
            onSortChange={setSortBy}
            currentCategory={selectedCategory}
            currentSort={sortBy}
          />

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filteredStories.slice(0, 6).map((story) => (
              <StoryCard key={story.id} story={story} />
            ))}
          </div>

          {filteredStories.length > 6 && (
            <div className="text-center mt-12">
              <Link
                href="/browse"
                className="bg-rose-600 text-white px-8 py-3 rounded-xl font-semibold hover:bg-rose-700 transition-colors inline-flex items-center whitespace-nowrap"
              >
                View All Stories
                <i className="ri-arrow-right-line ml-2"></i>
              </Link>
            </div>
          )}
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Explore by Category
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Find stories that resonate with your current journey or discover new perspectives on the human experience.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
            {[
              { name: 'Hope', icon: 'ri-sun-line', color: 'bg-blue-100 text-blue-600', count: 23 },
              { name: 'Kindness', icon: 'ri-heart-line', color: 'bg-green-100 text-green-600', count: 18 },
              { name: 'Healing', icon: 'ri-medicine-bottle-line', color: 'bg-purple-100 text-purple-600', count: 15 },
              { name: 'Faith', icon: 'ri-hand-heart-line', color: 'bg-yellow-100 text-yellow-600', count: 12 },
              { name: 'Loss', icon: 'ri-leaf-line', color: 'bg-gray-100 text-gray-600', count: 8 }
            ].map((category) => (
              <Link
                key={category.name}
                href={`/browse?category=${category.name.toLowerCase()}`}
                className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow text-center group"
              >
                <div className={`w-12 h-12 mx-auto mb-4 rounded-full flex items-center justify-center ${category.color} group-hover:scale-110 transition-transform`}>
                  <i className={`${category.icon} text-xl`}></i>
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">{category.name}</h3>
                <p className="text-sm text-gray-600">{category.count} stories</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}