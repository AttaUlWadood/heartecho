'use client';

import { useState, useMemo, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import StoryCard from '@/components/StoryCard';
import SearchAndFilter from '@/components/SearchAndFilter';
import { mockStories } from '@/lib/mockData';

function BrowseContent() {
  const searchParams = useSearchParams();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState(searchParams.get('category') || 'all');
  const [sortBy, setSortBy] = useState('newest');

  const filteredStories = useMemo(() => {
    let filtered = mockStories;

    if (searchQuery) {
      filtered = filtered.filter(story => 
        story.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        story.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
        story.author.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (selectedCategory !== 'all') {
      filtered = filtered.filter(story => 
        story.category.toLowerCase() === selectedCategory.toLowerCase()
      );
    }

    filtered.sort((a, b) => {
      if (sortBy === 'newest') {
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      } else {
        const aTotal = a.reactions.heart + a.reactions.cry + a.reactions.praise;
        const bTotal = b.reactions.heart + b.reactions.cry + b.reactions.praise;
        return bTotal - aTotal;
      }
    });

    return filtered;
  }, [searchQuery, selectedCategory, sortBy]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 to-orange-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Browse Stories
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Discover touching stories from our community. Each one offers a unique perspective on the human experience.
          </p>
        </div>

        <SearchAndFilter
          onSearch={setSearchQuery}
          onCategoryChange={setSelectedCategory}
          onSortChange={setSortBy}
          currentCategory={selectedCategory}
          currentSort={sortBy}
        />

        <div className="mb-6 flex items-center justify-between">
          <p className="text-gray-600">
            {filteredStories.length} {filteredStories.length === 1 ? 'story' : 'stories'} found
            {selectedCategory !== 'all' && (
              <span className="ml-2 inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-rose-100 text-rose-800">
                {selectedCategory}
              </span>
            )}
          </p>
        </div>

        {filteredStories.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="ri-search-line text-gray-400 text-2xl"></i>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No stories found</h3>
            <p className="text-gray-600 mb-6">
              Try adjusting your search terms or category filter to find more stories.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
              }}
              className="bg-rose-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-rose-700 transition-colors whitespace-nowrap"
            >
              View All Stories
            </button>
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filteredStories.map((story) => (
              <StoryCard key={story.id} story={story} />
            ))}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}

export default function BrowseStories() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-gradient-to-br from-rose-50 to-orange-50">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-rose-600 mx-auto"></div>
            <p className="mt-4 text-gray-600">Loading stories...</p>
          </div>
        </div>
        <Footer />
      </div>
    }>
      <BrowseContent />
    </Suspense>
  );
}