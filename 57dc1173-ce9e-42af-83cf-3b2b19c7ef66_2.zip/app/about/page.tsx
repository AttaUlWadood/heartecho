'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';

export default function About() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 to-orange-50">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-6">
            About HeartStories
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            A safe space where authentic stories create meaningful connections and remind us that we're never truly alone.
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 mb-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Our Mission</h2>
          <p className="text-gray-700 leading-relaxed mb-6">
            HeartStories was born from a simple belief: that sharing our most vulnerable moments has the power to heal both the storyteller and the listener. In a world that often feels disconnected, we provide a platform where real human experiences can bridge the gaps between us.
          </p>
          <p className="text-gray-700 leading-relaxed">
            Every story shared here is a testament to the resilience of the human spirit. Whether it's a moment of unexpected kindness, a journey through loss, or a discovery of inner strength, these narratives remind us of our shared humanity and the threads that connect us all.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
              <i className="ri-heart-line text-blue-600 text-xl"></i>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">Safe & Supportive</h3>
            <p className="text-gray-700">
              We've created a judgment-free environment where vulnerability is celebrated and every story is treated with respect and care.
            </p>
          </div>

          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-4">
              <i className="ri-shield-check-line text-green-600 text-xl"></i>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">Carefully Moderated</h3>
            <p className="text-gray-700">
              Every story is reviewed by our team to ensure it meets our community standards while preserving the authentic voice of each contributor.
            </p>
          </div>

          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
            <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mb-4">
              <i className="ri-group-line text-purple-600 text-xl"></i>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">Community Focused</h3>
            <p className="text-gray-700">
              Our platform is built around the idea that healing happens in community. Every interaction is designed to foster connection and understanding.
            </p>
          </div>

          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
            <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mb-4">
              <i className="ri-lightbulb-line text-yellow-600 text-xl"></i>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">Inspiring Change</h3>
            <p className="text-gray-700">
              We believe that stories have the power to inspire positive change, both in individuals and in our broader communities.
            </p>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 mb-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">How It Works</h2>
          <div className="space-y-6">
            <div className="flex items-start space-x-4">
              <div className="w-8 h-8 bg-rose-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-rose-600 font-semibold">1</span>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-1">Share Your Story</h3>
                <p className="text-gray-700">Write about your personal experience using our simple submission form. You can choose to share anonymously or with your name.</p>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="w-8 h-8 bg-rose-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-rose-600 font-semibold">2</span>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-1">Review Process</h3>
                <p className="text-gray-700">Our team carefully reviews each submission to ensure it meets our community guidelines while preserving your authentic voice.</p>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="w-8 h-8 bg-rose-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-rose-600 font-semibold">3</span>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-1">Connect & Heal</h3>
                <p className="text-gray-700">Once published, your story becomes part of our community, where it can touch lives and create meaningful connections.</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-rose-500 to-orange-500 rounded-2xl p-8 text-white text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Share Your Story?</h2>
          <p className="text-rose-100 mb-6 max-w-2xl mx-auto">
            Your experience matters. Your story could be exactly what someone needs to hear today. Join our community of storytellers and make a difference.
          </p>
          <Link
            href="/submit"
            className="bg-white text-rose-600 px-8 py-3 rounded-xl font-semibold hover:bg-rose-50 transition-colors inline-flex items-center whitespace-nowrap"
          >
            <i className="ri-heart-line mr-2"></i>
            Share Your Story
          </Link>
        </div>
      </div>

      <Footer />
    </div>
  );
}