'use client';

import { useState } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { categories } from '@/lib/mockData';

export default function SubmitStory() {
  const [formData, setFormData] = useState({
    name: '',
    title: '',
    content: '',
    category: 'hope'
  });
  const [charCount, setCharCount] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errors, setErrors] = useState<any>({});

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    
    if (name === 'content') {
      if (value.length > 500) return;
      setCharCount(value.length);
    }
    
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    if (errors[name]) {
      setErrors((prev: any) => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors: any = {};
    
    if (!formData.title.trim()) {
      newErrors.title = 'Story title is required';
    }
    
    if (!formData.content.trim()) {
      newErrors.content = 'Story content is required';
    } else if (formData.content.length < 50) {
      newErrors.content = 'Story must be at least 50 characters long';
    }
    
    if (!formData.category) {
      newErrors.category = 'Please select a category';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setIsSubmitting(true);
    
    try {
      const submitData = new URLSearchParams();
      submitData.append('name', formData.name || 'Anonymous');
      submitData.append('title', formData.title);
      submitData.append('content', formData.content);
      submitData.append('category', formData.category);
      
      await fetch('/api/submit-story', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: submitData.toString(),
      });
      
      setIsSubmitted(true);
      setFormData({
        name: '',
        title: '',
        content: '',
        category: 'hope'
      });
      setCharCount(0);
    } catch (error) {
      console.error('Error submitting story:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-rose-50 to-orange-50">
        <Header />
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="ri-check-line text-green-600 text-2xl"></i>
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Thank You for Sharing
            </h2>
            <p className="text-gray-600 mb-6">
              Your story has been submitted for review. We'll carefully read it and publish it once approved. 
              Thank you for your courage in sharing your experience.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => setIsSubmitted(false)}
                className="bg-rose-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-rose-700 transition-colors whitespace-nowrap"
              >
                Share Another Story
              </button>
              <a
                href="/"
                className="bg-white text-rose-600 px-6 py-3 rounded-xl font-semibold border-2 border-rose-600 hover:bg-rose-50 transition-colors whitespace-nowrap"
              >
                Browse Stories
              </a>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 to-orange-50">
      <Header />
      
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Share Your Story
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Your experiences matter. By sharing your story, you create connections and help others feel less alone in their journey.
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
          <form id="story-submission" onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                Your Name <span className="text-gray-500">(optional)</span>
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                placeholder="Leave blank to post anonymously"
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent"
              />
              <p className="mt-1 text-sm text-gray-500">
                Your name will be displayed as the story author. Leave blank to remain anonymous.
              </p>
            </div>

            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-2">
                Story Title <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                id="title"
                name="title"
                value={formData.title}
                onChange={handleInputChange}
                placeholder="Give your story a meaningful title"
                className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent ${
                  errors.title ? 'border-red-500' : 'border-gray-300'
                }`}
                required
              />
              {errors.title && <p className="mt-1 text-sm text-red-600">{errors.title}</p>}
            </div>

            <div>
              <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-2">
                Category <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <select
                  id="category"
                  name="category"
                  value={formData.category}
                  onChange={handleInputChange}
                  className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent pr-8 ${
                    errors.category ? 'border-red-500' : 'border-gray-300'
                  }`}
                  required
                >
                  {categories.slice(1).map((category) => (
                    <option key={category.value} value={category.value}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </div>
              {errors.category && <p className="mt-1 text-sm text-red-600">{errors.category}</p>}
            </div>

            <div>
              <label htmlFor="content" className="block text-sm font-medium text-gray-700 mb-2">
                Your Story <span className="text-red-500">*</span>
              </label>
              <textarea
                id="content"
                name="content"
                value={formData.content}
                onChange={handleInputChange}
                placeholder="Share your story here. Write from the heart - your authentic experience can make a real difference in someone's life."
                rows={12}
                maxLength={500}
                className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent resize-none ${
                  errors.content ? 'border-red-500' : 'border-gray-300'
                }`}
                required
              />
              <div className="flex justify-between items-center mt-2">
                <div>
                  {errors.content && <p className="text-sm text-red-600">{errors.content}</p>}
                </div>
                <p className={`text-sm ${charCount > 450 ? 'text-red-500' : 'text-gray-500'}`}>
                  {charCount}/500 characters
                </p>
              </div>
            </div>

            <div className="bg-rose-50 border border-rose-200 rounded-xl p-4">
              <h3 className="font-semibold text-rose-800 mb-2">Before you submit:</h3>
              <ul className="text-sm text-rose-700 space-y-1">
                <li>• All stories are reviewed before publication</li>
                <li>• Please ensure your story is truthful and personal</li>
                <li>• Avoid including identifying information about others</li>
                <li>• Stories should be appropriate for all audiences</li>
              </ul>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 pt-6">
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex-1 bg-rose-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-rose-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
              >
                {isSubmitting ? (
                  <>
                    <i className="ri-loader-4-line animate-spin mr-2"></i>
                    Submitting...
                  </>
                ) : (
                  <>
                    <i className="ri-heart-line mr-2"></i>
                    Submit Story
                  </>
                )}
              </button>
              <button
                type="button"
                onClick={() => {
                  setFormData({
                    name: '',
                    title: '',
                    content: '',
                    category: 'hope'
                  });
                  setCharCount(0);
                  setErrors({});
                }}
                className="flex-1 bg-white text-gray-600 px-6 py-3 rounded-xl font-semibold border-2 border-gray-300 hover:bg-gray-50 transition-colors whitespace-nowrap"
              >
                Clear Form
              </button>
            </div>
          </form>
        </div>
      </div>

      <Footer />
    </div>
  );
}